     # Open file dialog to select an image
        filepath, _ = QFileDialog.getOpenFileName(self, "Open Image File", "", "Image files (*.jpg *.png)")

        if filepath:
            # Read the image
            img = cv2.imread(filepath)

            # Convert image to grayscale
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            # Define the kernel
            kernel = np.array([[6, 0, -6],
                                [6, 1, -6],
                                [6, 0, -6]])

            # Apply convolution
            img_out = cv2.filter2D(img_gray, -1, kernel)

            # Display the filtered image within the application
            self.displayFilteredImg(img_out)